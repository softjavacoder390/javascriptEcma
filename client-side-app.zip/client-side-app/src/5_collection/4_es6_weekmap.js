// let myMap = new Map();

// const obj1 = { id: 1 };
// const obj2 = { id: 2 };

// myMap.set(obj1, 'This is the value for Object One');
// myMap.set(obj2, 'This is the value for Object Two');

// obj1 = undefined;

// --------------------------------------------
let wMap = new WeakMap();

var obj1 = { id: 1 };
const obj2 = { id: 2 };

wMap.set(obj1, 'This is the value for Object One');
wMap.set(obj2, 'This is the value for Object Two');

console.log(wMap);

//obj1 = undefined;

console.log(wMap);


// WeakMap keys must be object
// WeakMap is not iterable
// for (const item of wMap) {
//     console.log(item);
// }