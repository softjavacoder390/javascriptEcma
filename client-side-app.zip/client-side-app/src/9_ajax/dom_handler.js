// import postApiClient from "./post_api_client";

// var ajaxDiv = document.getElementById("ajaxDiv");
// var messageDiv = document.getElementById("messageDiv");

// if (ajaxDiv.style.display === "none") {
//     ajaxDiv.style.display = "block";
//     messageDiv.style.display = "none";
// }

// var button = document.createElement("button");
// button.className = "btn btn-primary";
// button.innerHTML = "Get Data";

// var btnArea = document.getElementById("btnArea");
// btnArea.appendChild(button);

// button.addEventListener("click", function () {
//     // alert("Button was clicked....");
//     postApiClient.getAllPosts();
// });

// function generateTable(data) {
//     let table = document.getElementById("postTable");
//     let row, cell;

//     for (const item of data) {
//         row = table.insertRow();
//         cell = row.insertCell();
//         cell.textContent = item.id;
//         cell = row.insertCell();
//         cell.textContent = item.title;
//         cell = row.insertCell();
//         cell.textContent = item.body;
//     }
// }


 //----------------------------


 import postApiClient from "./post_api_client";

var ajaxDiv = document.getElementById("ajaxDiv");
var messageDiv = document.getElementById("messageDiv");

if (ajaxDiv.style.display === "none") {
    ajaxDiv.style.display = "block";
    messageDiv.style.display = "none";
}

var button = document.createElement("button");
button.className = "btn btn-primary";
button.innerHTML = "Get Data";

var btnArea = document.getElementById("btnArea");
btnArea.appendChild(button);

// 1. Using Callback
// button.addEventListener("click", function () {
//     // alert("Button was clicked....");
//     postApiClient.getAllPostsUsingCallbacks((data) => {
//         generateTable(data);
//     }, (eMsg) => {
//         console.error(eMsg);
//     });
// });

// 2. Using Promise
// button.addEventListener("click", function () {
//     postApiClient.getAllPostsUsingPromise().then((data) => {
//         generateTable(data);
//     }).catch((eMsg) => {
//         console.error(eMsg);
//     });
// });

// 3. Using Async Await
// button.addEventListener("click", async function () {
//     try {
//         var result = await postApiClient.getAllPostsUsingPromise();
//         generateTable(result);
//     } catch(eMsg) {
//         console.error(eMsg);
//     }
// });

// 4. Using Async Function
// button.addEventListener("click", async function () {
//     try {
//         var result = await postApiClient.getAllPostsAsync();
//         generateTable(result);
//     } catch(eMsg) {
//         console.error(eMsg);
//     }
// });

// 5. Using Async Generators
button.addEventListener("click", async function () {
    const it = postApiClient.getAllPosts();

    try {
        var result = await it.next();
        generateTable(result.value);
    } catch (eMsg) {
        console.error(eMsg);
    }
});

function generateTable(data) {
    let table = document.getElementById("postTable");
    let row, cell;

    for (const item of data) {
        row = table.insertRow();
        cell = row.insertCell();
        cell.textContent = item.id;
        cell = row.insertCell();
        cell.textContent = item.title;
        cell = row.insertCell();
        cell.textContent = item.body;
    }
}