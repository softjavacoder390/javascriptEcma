 // https://1drv.ms/u/s!Ao-ceLq5rZm3hrMOKw-rJ9t88MqkfA?e=qRCfTA

 // https://onedrive.live.com/?authkey=%21ACsPqyfbfPDKpHw&id=B799ADB9BA789C8F%21104846&cid=B799ADB9BA789C8F

// const url = "https://jsonplaceholder.typicode.com/posts";

// const postApiClient = {
//     getAllPosts: function () {
//         fetch(url).then(response => {
//             response.json().then(data => { 
//                 console.log(data);
//             }).catch(err => {
//                 console.error(err);
//             })
//         }).catch(err => {
//             console.error(err);
//         });
//     }
// };

// export default postApiClient;


//-----------------------------

// https://1drv.ms/u/s!Ao-ceLq5rZm3hrMOKw-rJ9t88MqkfA?e=qRCfTA

// https://onedrive.live.com/?authkey=%21ACsPqyfbfPDKpHw&id=B799ADB9BA789C8F%21104846&cid=B799ADB9BA789C8F

const url = "https://jsonplaceholder.typicode.com/posts";

const postApiClient = {
    getAllPostsUsingCallbacks: function (successCB, errorCB) {
        fetch(url).then(response => {
            response.json().then(data => {
                successCB(data);
            }).catch(err => {
                errorCB("Parsing Error...");
            })
        }).catch(err => {
            errorCB("Communication Error...");
        });
    },

    getAllPostsUsingPromise: function () {
        return new Promise((resolve, reject) => {
            fetch(url).then(response => {
                response.json().then(data => {
                    resolve(data);
                }).catch(err => {
                    reject("Parsing Error...");
                })
            }).catch(err => {
                reject("Communication Error...");
            });
        });
    },

    getAllPostsAsync: async function () {
        try {
            var response = await fetch(url);
            var data = await response.json();
            return data;
        } catch(err) {
            throw err;
        }
    },

    getAllPosts: async function* () {
        try {
            var response = await fetch(url);
            yield await response.json();
        } catch(err) {
            throw err;
        }
    }
};

export default postApiClient;