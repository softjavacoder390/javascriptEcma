import { square } from './mone';
import { check } from './mtwo';
import { test } from './mthree';

// export default {
//     square, check, test
// }

export const app = {
    square, check, test
};