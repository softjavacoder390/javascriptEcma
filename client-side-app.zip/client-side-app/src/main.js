// import './1_datatypes/1_declarations';
//import './1_datatypes/2_es6_declarations'
//import './1_datatypes/3_es6_declarations'
//import './1_datatypes/4_datatypes'
//import './1_datatypes/5_operators.js'
//import "./1_datatypes/6_symbols";
//import './2_functions/1_fn_creation';
//import './2_functions/2_fn_parameters';
//import './2_functions/3_rest_spread';
//import './2_functions/4_pure_impure';
//import './2_functions/5_iife'
//import './assignments/filterexample.js'
// import './3_funcationOver/1_funoverloading'
// import './3_funcationOver/2_arrowfunction.js'
// import './3_funcationOver/3_as_argument'
// import './3_funcationOver/4_callback';
// import './3_funcationOver/5_clouser';
// import './3_funcationOver/6_fn_context'
// import './3_funcationOver/7_fn_currying'
// import './3_funcationOver/8_hof';
// import './4_object/1_obj_creation'
// import './4_object/2_obj_creation';
// import './4_object/3_object_type';
// import './4_object/4_object_method'
// import './4_object/5_custom_object'
// import './4_object/6_using_prototype'
// import './4_object/7_es6_class';
// import './4_object/8_compare';
// import './4_object/9_es5_properties'
// import './5_collection/1_arrays';
// import './5_collection/2_es6_map'
// import './5_collection/3_es6_set'
// import './5_collection/4_es6_weekmap'
// import './6_iterators/1_well_known'
// import './6_iterators/2_custom_iter';
// import './6_iterators/3_generator'
// import './7_modules/usage'
// import './8_promise/1_promise_creation'
// import './8_promise/2_chaining_promise'
import './8_promise/3_promise_method'

// import './9_ajax/dom_handler';



console.log("Hello from Main File....");
//console.log("a22 is: ", a);


