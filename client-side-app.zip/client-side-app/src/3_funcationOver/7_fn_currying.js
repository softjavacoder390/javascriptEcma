// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Subodh");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(" INR", 77.36, 0, 100));
// console.log(Converter(" INR", 77.36, 0, 250));
// console.log(Converter(" INR", 77.36, 0, 599));
// console.log(Converter(" INR", 77.36, 0, 999));

// --------------------------------------------------------- Default Parameters

// function Converter(input, toUnit = " INR", factor = 77.36, offset = 0) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(100));
// console.log(Converter(250));
// console.log(Converter(599));
// console.log(Converter(999));

// console.log(Converter(100, " KM", 1.6, 0));
// console.log(Converter(250, " KM", 1.6, 0));
// console.log(Converter(599, " KM", 1.6, 0));
// console.log(Converter(999, " KM", 1.6, 0));

// -------------------------------------------------------- Solution
// function greetings(message) {
//     return function(name) {
//         console.log(`${message}, ${name}`)
//     }
// }

// const mGreet = greetings("Good Morning");
// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Subodh");

// const aGreet = greetings("Good Afternoon");
// aGreet("Abhijeet");
// aGreet("Ramakant");
// aGreet("Subodh");

//---------------------------

// function Converter(toUnit, factor, offset) {
//     return function(input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// const usdToInrConverter = Converter(" INR", 77.36, 0);
// console.log(usdToInrConverter(100));
// console.log(usdToInrConverter(250));
// console.log(usdToInrConverter(599));
// console.log(usdToInrConverter(999));

// console.log("\n");
// const milesToKmConverter = Converter(" KM", 1.6, 0);
// console.log(milesToKmConverter(100));
// console.log(milesToKmConverter(250));
// console.log(milesToKmConverter(599));
// console.log(milesToKmConverter(999));

// ---------------------------------------------------------------

// function greetings(cb, message, name) {
//     cb(`${message}, ${name}`)
// }

// function display(msg) { 
//     console.log(msg); 
// }

// greetings(display, "Good Morning", "Abhijeet");
// greetings(display, "Good Morning", "Ramakant");
// greetings(display, "Good Morning", "Subodh");

// function greetings(cb, message) {
//     return function(name) {
//         cb(`${message}, ${name}`);
//     }
// }

// function display(msg) { 
//     console.log(msg); 
// }

// const mGreet = greetings(display, "Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Subodh");