// var employees = ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

// function filter(dataArr, x) {
//     let newArr = [];

//     for (const name of dataArr) {
//         if (name[0] === x) {
//             newArr.push(name);
//         }

//         // if (name.charAt(0) === x) {
//         //     newArr.push(name);
//         // }

//         // if (name.startsWith(x)) {
//         //     newArr.push(name);
//         // }

//         // var testString = "^" + x;
//         // if (name.match(testString)) {
//         //     newArr.push(name);
//         // }
//     }

//     return newArr;
// }

// var result1 = filter(employees, 'A');
// console.log(result1);                   // ["Akshay"];

// var result2 = filter(employees, 'B');
// console.log(result2);                   // ["Basavaraj", "Bhavya", "Bibhu"];

// var result3 = filter(employees, 'C');
// console.log(result3);                   // ["Chethan", "Chhavi"];

// console.log(employees);                 // ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

// function Add(...args) {
//     if (args.length === 2 || args.length === 3){
//         var sum = 0;
//         for (const n of args) {
//         sum += n;
//         }
//             return sum;
//     }
//     else
//         throw Error("if you are passing less than 2 or more than 3 arguments");
// }

// console.log(Add(2, 3));
// console.log(Add(2, 3, 4));
// console.log(Add(2));        // Show Error, if you are passing less than 2 or more than 3 arguments

// const Add = (function () {
    //     function m1(x, y) {
    //         return x + y;
    //     }
    
    //     function m2(x, y, z) {
    //         return x + y + z;
    //     }
    
    //     return function () {
    //         if (arguments.length === 2)
    //             return m1(arguments[0], arguments[1]);
    //         else if (arguments.length === 3)
    //             return m2(arguments[0], arguments[1], arguments[2]);
    //         else
    //             throw Error("Invalid Paramaters...");
    //     }
    // })();
    
    function Add(...args) {
        if (args.length === 2)
            return args[0] + args[1];
        else if (arguments.length === 3)
            return args[0] + args[1] + args[2];
        else
            throw Error("Invalid Paramaters...");
    }
    
    console.log(Add(2, 3));
    console.log(Add(2, 3, 4));
    try {
        console.log(Add(2));        // Show Error, if you are passing less than 2 or more than 3 arguments
    } catch (e) {
        console.error(e.message);
    }

    //--------------------------------
    // Assignment - Create a Fibonacci Class to generate Fibonacci Series for given number of items using generators

class Fibonacci {
    constructor(noOfItems) {
        this._noOfItems = noOfItems;
    }

    *[Symbol.iterator]() {
        let a = 0, b = 1, i = 0;

        while (i < this._noOfItems) {
            i++;
            let current = a;
            a = b;
            b = current + a;
            yield current;
        }
    }
}

let fibObject = new Fibonacci(10);

// for (const i of fibObject) {
//     console.log(i);
// }

let series = [...fibObject];
console.log(series);


//------------------------------------

