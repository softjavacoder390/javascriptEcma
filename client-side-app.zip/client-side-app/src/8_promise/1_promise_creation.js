// function pushData(cb) {
//     setTimeout(function () {
//         cb(1000);
//     }, 5000)
// }

// pushData((data) => {
//     console.log("Result: ", data);
// });

// // A - Arrange for Inputs
// // A - Act (Call the method to test, passing the arguments & get the returned value)
// // A - Assert (Check, Returned Value == Expected Result)

// // Testing Becomes Difficult on Functions which accept Callback
// // Callback Hell
// // Callback Inside Callback will only be Handled Synchronously

// asyncFunc(1, () => {
//     asyncFunc(2, () => {
//         asyncFunc(3, () => {
//             asyncFunc(4, () => {

//             })
//         })
//     })
// })

// // To Resolve these problem areas, we have promise, async await, observables, CSP

function getData() {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            // resolve(1000);
            reject("Some Error...");
        }, 5000)
    });

    return promise;
}

var promise = getData();

// promise.then((data) => {
//     console.log("Success: ", data);
// }, (err) => {
//     console.error("Error: ", err);
// });

// promise.then((data) => {
//     console.log("Success: ", data);
// }).catch((err) => {
//     console.error("Error: ", err);
// });

// ECMASCRIPT 2018 - Promise finally
promise.then((data) => {
    console.log("Success: ", data);
}).catch((err) => {
    console.error("Error: ", err);
}).finally(() => { 
    console.warn("Finally will always run");
});