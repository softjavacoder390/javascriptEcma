// function getIterator() {
//     const arr = [1, 2, 3, 4, 5];

//     return {
//         next: function () {
//             if (arr.length) {
//                 return {
//                     value: arr.shift(),
//                     done: false
//                 }
//             } else {
//                 return {
//                     done: true
//                 };
//             }
//         }
//     };
// }

// // var it = getIterator();

// // (function() {
// //     console.log(it.next());
// //     console.log(it.next());
// //     console.log(it.next());
// //     console.log(it.next());
// //     console.log(it.next());
// //     console.log(it.next());
// // })();

// var myIterable = {
//     [Symbol.iterator]: getIterator
// };

// for (const item of myIterable) {
//     console.log(item);
// }

// -------------------------------------------------

function getAsyncIterator() {
    const arr = [1, 2, 3, 4, 5];

    return {
        next: function () {
            if (arr.length) {
                return Promise.resolve({
                    value: arr.shift(),
                    done: false
                });
            } else {
                return Promise.resolve({
                    done: true
                });
            }
        }
    };
}

// var it = getAsyncIterator();

// (function() {
//     it.next().then(console.log);
//     it.next().then(console.log);
//     it.next().then(console.log);
//     it.next().then(console.log);
//     it.next().then(console.log);
//     it.next().then(console.log);
// })();

var myIterable = {
    [Symbol.asyncIterator]: getAsyncIterator
};

// for-await-of
(async function () {
    for await (const item of myIterable) {
        console.log(item);
    }
})();

console.log("Last Line");
