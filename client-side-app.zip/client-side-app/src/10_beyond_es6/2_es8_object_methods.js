// var person = { id: 1, name: "Manish" };

// // ES 6
// // for (const key in person) {
// //     console.log(key, person[key]);
// // }

// for (const key of Object.keys(person)) {
//     console.log(key, person[key]);
// }

// // ES 8
// // Object.values(), Object.entries()

// for (const value of Object.values(person)) {
//     console.log(value);
// }

// for (const pair of Object.entries(person)) {
//     console.log(pair);
// }

// for (const [key, value] of Object.entries(person)) {
//     console.log(`${key} -   ${value}`);
// }

// -----------------------------------------------------------

var person = {};

Object.defineProperty(person, "firstname", {
    value: "NA",
    writable: true,
    enumerable: true
});

// for (const key in person) {
//     console.log(key);
// }

var p_desp = Object.getOwnPropertyDescriptor(person, 'firstname');
console.log(p_desp);