// let result = Math.pow(2, 4);
// console.log(result);

// // Exponentiation Operator
// let result1 = 2 ** 4;
// console.log(result1);

// let a = 2, b = 4;
// // a = a ** b;
// a **= b;
// console.log(a);

// // Negative base should be kept in ()
// let result3 = (-3) ** 7;
// console.log(result3);

// ---------------------------------------------------------

let arr = ["ReactJS", "Angular", "ExtJS"];

// Before ES7 - Problem
// if (arr.indexOf('ReactJS')) {
//     console.log("React is available...");
// } else {
//     console.error("React is not available...");
// }

// if (arr.indexOf('VueJS')) {
//     console.log("VueJS is available...");
// } else {
//     console.error("VueJS is not available...");
// }

// console.log(arr.indexOf('ReactJS'));
// console.log(arr.indexOf('VueJS'));

// console.log(Boolean(arr.indexOf('ReactJS')));
// console.log(Boolean(arr.indexOf('VueJS')));

// In ES7 - Solution
if (arr.includes('ReactJS')) {
    console.log("React is available...");
} else {
    console.error("React is not available...");
}

if (arr.includes('VueJS')) {
    console.log("VueJS is available...");
} else {
    console.error("VueJS is not available...");
}