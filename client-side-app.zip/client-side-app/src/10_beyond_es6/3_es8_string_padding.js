// console.log("Manish");
// console.log("Satish Sharma");

console.log("Manish".padStart(20));
console.log("Satish Sharma".padStart(20));

console.log("0.00".padStart(20));
console.log("10000.00".padStart(20));
console.log("1000.00".padStart(20));
console.log("100000.00".padStart(20));

console.log("1000.00".padStart(20, "-"));
console.log("10.00".padStart(20, "-"));

console.log("Manish".padEnd(20, '-'), "Sharma");