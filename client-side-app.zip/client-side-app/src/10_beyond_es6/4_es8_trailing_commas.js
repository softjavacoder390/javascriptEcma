var arr = [10, 20, 30, 40, 50,];
console.log(arr);

var person = { id: 1, name: "Manish", };
console.log(person);

// ES8 - Function with Trailing Comma
var fn = function (a, b,) {
    console.log(a, b);
}

console.log(fn);
fn(2, 3)
fn(2, 3, 4)