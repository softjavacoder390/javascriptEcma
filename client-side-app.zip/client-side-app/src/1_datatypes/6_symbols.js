// ---------------------------------------------------------------- Primitive Type (Immutable)

 

// // Create a function, which should compare and give true, only if, color const is passed to it as an argument

//const color = "red";
// function isRedColor(arg) {
//     console.log(arg === color);
// }

// isRedColor(color);
// isRedColor("red");

//  var clr = "red";
//  isRedColor(clr);

// ---------------------------------------------------------------- Object (Mutable)

 

// // Create a function, which should compare and give true, only if, color const is passed to it as an argument

// const color = { code: "red" };
// function isRedColor(arg) {
//     console.log(arg === color);
// }

// isRedColor(color);
// isRedColor({ code: "red" });

// var clr = { code: "red" };
// isRedColor(clr);

// ---------------------------------------------------------------- Primitive Type (Immutable)
// Symbol (Unique Immutable)

 

// Create a function, which should compare and give true, only if, color const is passed to it as an argument

// const color = Symbol("red");
// function isRedColor(arg) {
//     console.log(arg === color);
// }

// isRedColor(color);
// isRedColor(Symbol("red"));

// var clr = Symbol("red");
// isRedColor(clr);
// console.log('datatype of color :' ,typeof color);