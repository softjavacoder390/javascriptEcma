// var person = {
    // id: 1,
    // name: "Manish",
    // username: "ManishS",
    // password: "ManishS",
    // address: {
    //     city: "Pune"
    // }
// };

var password = Symbol("password");  //object serilization

var person = {
    id: 1,
    name: "Manish",
    [Symbol("username")]: "ManishS",
    [password]: "ManishS",
    address: {
        city: "Pune"
    }
};

console.log(person);
console.log(person[password]);
console.log(person[Symbol("username")]);

const person_JSON = JSON.stringify(person);
console.log(person_JSON);